﻿//Coiped from https://gist.github.com/jasonweng/393aef0c05c425d8dcfdb2fc1a8188e5

function saveFileReceivedViaAJAX(response, status, xhr) {
    var downloadLocation = xhr.getResponseHeader('Location');
    window.location.href = downloadLocation;
    toastr.success("Certificate is generated and downloaded to the file system");
}