﻿//Coiped from https://gist.github.com/jasonweng/393aef0c05c425d8dcfdb2fc1a8188e5

function saveFileReceivedViaAJAX(response, status, xhr) {
    var downloadLocation = xhr.getResponseHeader('Location');
    window.location.href = downloadLocation;
    toastr.success("Certificate is generated and downloaded to the file system");
}

function saveBlob(blob, contentDisposition) {
    // https://stackoverflow.com/a/23054920/
    var fileName = contentDisposition.match(/filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/)[1];

    var a = document.createElement('a');
    a.href = window.URL.createObjectURL(blob);
    a.download = fileName;
    a.dispatchEvent(new MouseEvent('click'));
}